package com.example.edwin.sorteo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DosPersonasActivity extends AppCompatActivity implements View.OnClickListener{

    EditText text1;
    EditText text2;
    Button btnejecutar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dos_personas);

        text1 = (EditText) findViewById(R.id.etxt1);
        text2 = (EditText) findViewById(R.id.etxt2);
        btnejecutar = (Button) findViewById(R.id.btn_ejecutar);
        btnejecutar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {




    }
}
